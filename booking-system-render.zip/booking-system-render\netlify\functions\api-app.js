// Express app موحد للتطوير المحلي وNetlify

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { initDatabase, getDatabase, saveData, getNextId } = require('../../server/database');

const app = express();

// Load environment variables
require('dotenv').config();

// إنشاء JWT_SECRET تلقائياً إذا لم يكن موجوداً
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  JWT_SECRET = crypto.randomBytes(64).toString('hex');
  console.log('🔷 [INIT] تم إنشاء JWT_SECRET تلقائياً');
}
console.log('🔷 [INIT] JWT_SECRET:', JWT_SECRET ? 'موجود (' + JWT_SECRET.substring(0, 10) + '...)' : 'غير موجود');

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Initialize database
const initDbOnce = async () => {
  console.log('🔷 [DB_INIT] بدء تهيئة قاعدة البيانات...');
  try {
    await initDatabase();
    console.log('✅ Database ready');
  } catch (error) {
    console.error('❌ Database initialization error, retrying...', error);
    try {
      await initDatabase();
      console.log('✅ Database re-initialized successfully');
    } catch (retryError) {
      console.error('❌ Database initialization failed:', retryError);
      throw retryError;
    }
  }
};

// Middleware للتحقق من التوكن
function authenticateToken(req, res, next) {
  console.log('🟡 [AUTH] التحقق من التوكن');
  const authHeader = req.headers['authorization'];
  console.log('🟡 [AUTH] Authorization header:', authHeader ? 'موجود' : 'غير موجود');
  
  const token = authHeader && authHeader.split(' ')[1];
  console.log('🟡 [AUTH] Token:', token ? token.substring(0, 20) + '...' : 'null');

  if (!token) {
    console.log('❌ [AUTH] لا يوجد token');
    return res.status(401).json({ error: 'التوكن مطلوب' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log('✅ [AUTH] Token صالح للمستخدم:', decoded.email);
    req.user = decoded;
    next();
  } catch (error) {
    console.log('❌ [AUTH] Token غير صالح:', error.message);
    return res.status(403).json({ error: 'توكن غير صحيح' });
  }
}

// Middleware للتحقق من أن المستخدم أدمن
function isAdmin(req, res, next) {
  console.log('🟡 [ADMIN] التحقق من صلاحيات الأدمن');
  console.log('🟡 [ADMIN] User role:', req.user ? req.user.role : 'null');
  
  if (req.user.role !== 'admin') {
    console.log('❌ [ADMIN] المستخدم ليس أدمن');
    return res.status(403).json({ error: 'غير مصرح لك بالوصول' });
  }
  console.log('✅ [ADMIN] المستخدم أدمن');
  next();
}

// التحقق من صحة رقم الهاتف السعودي
function validateSaudiPhone(phone) {
  if (!phone) return false;
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  const saudiPattern = /^(\+966|966|05|5)[0-9]{8,9}$/;
  return saudiPattern.test(cleaned);
}

// تحويل رقم الهاتف إلى صيغة موحدة
function normalizeSaudiPhone(phone) {
  if (!phone) return null;
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  if (cleaned.startsWith('05')) {
    return '+966' + cleaned.substring(2);
  } else if (cleaned.startsWith('5') && cleaned.length === 9) {
    return '+966' + cleaned;
  } else if (cleaned.startsWith('966')) {
    return '+' + cleaned;
  } else if (cleaned.startsWith('+966')) {
    return cleaned;
  }
  return cleaned;
}

// ========== Authentication Routes ==========

// تسجيل الدخول
app.post('/api/auth/login', async (req, res) => {
  console.log('🔵 [LOGIN] بدء تسجيل الدخول');
  console.log('🔵 [LOGIN] Request body:', JSON.stringify(req.body));
  
  try {
    console.log('🔵 [LOGIN] تهيئة قاعدة البيانات...');
    await initDbOnce();
    
    const { email, password } = req.body;
    console.log('🔵 [LOGIN] Email:', email);
    console.log('🔵 [LOGIN] Password length:', password ? password.length : 'null');
    
    const data = getDatabase();
    console.log('🔵 [LOGIN] عدد المستخدمين في قاعدة البيانات:', data.users ? data.users.length : 0);

    const user = data.users.find(u => u.email === email && u.isActive === true);
    console.log('🔵 [LOGIN] المستخدم موجود:', user ? 'نعم' : 'لا');
    
    if (user) {
      console.log('🔵 [LOGIN] بيانات المستخدم:');
      console.log('   - ID:', user.id);
      console.log('   - Name:', user.name);
      console.log('   - Email:', user.email);
      console.log('   - Role:', user.role);
      console.log('   - Password hash length:', user.password ? user.password.length : 'null');
      console.log('   - Password hash start:', user.password ? user.password.substring(0, 10) : 'null');
    }

    if (!user) {
      console.log('❌ [LOGIN] المستخدم غير موجود أو غير نشط');
      return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    }

    // التحقق من أن كلمة المرور hash صحيح
    console.log('🔵 [LOGIN] التحقق من hash كلمة المرور...');
    if (!user.password || user.password.length < 20 || (!user.password.startsWith('$2b$') && !user.password.startsWith('$2a$'))) {
      console.error('❌ [LOGIN] كلمة المرور غير hash بشكل صحيح');
      console.error('   - Password exists:', !!user.password);
      console.error('   - Password length:', user.password ? user.password.length : 0);
      console.error('   - Password start:', user.password ? user.password.substring(0, 20) : 'null');
      return res.status(500).json({ error: 'خطأ في قاعدة البيانات - كلمة المرور غير صحيحة' });
    }
    console.log('✅ [LOGIN] Hash كلمة المرور صحيح');
    
    // مقارنة كلمة المرور
    console.log('🔵 [LOGIN] مقارنة كلمة المرور...');
    const validPassword = await bcrypt.compare(password, user.password);
    console.log('🔵 [LOGIN] نتيجة المقارنة:', validPassword ? 'صحيح' : 'خاطئ');
    
    if (!validPassword) {
      console.log('❌ [LOGIN] كلمة المرور خاطئة');
      return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' });
    }

    console.log('🔵 [LOGIN] إنشاء JWT token...');
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    console.log('✅ [LOGIN] Token تم إنشاؤه بنجاح');
    console.log('✅ [LOGIN] تسجيل الدخول ناجح للمستخدم:', user.email);

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        department: user.department
      }
    });
  } catch (error) {
    console.error('❌ [LOGIN] خطأ في تسجيل الدخول:', error);
    console.error('❌ [LOGIN] Stack:', error.stack);
    res.status(500).json({ error: 'خطأ في تسجيل الدخول' });
  }
});

// إضافة مستخدم جديد (أدمن فقط)
app.post('/api/admin/users', authenticateToken, isAdmin, async (req, res) => {
  console.log('🟢 [ADD_USER] بدء إضافة مستخدم جديد');
  console.log('🟢 [ADD_USER] Request body:', JSON.stringify(req.body));
  
  try {
    console.log('🟢 [ADD_USER] تهيئة قاعدة البيانات...');
    await initDbOnce();
    
    const { name, email, password, phone, department } = req.body;
    console.log('🟢 [ADD_USER] البيانات المستلمة:');
    console.log('   - Name:', name);
    console.log('   - Email:', email);
    console.log('   - Password length:', password ? password.length : 'null');
    console.log('   - Phone:', phone);
    console.log('   - Department:', department);
    
    const data = getDatabase();
    console.log('🟢 [ADD_USER] عدد المستخدمين الحالي:', data.users ? data.users.length : 0);

    if (!name || !email || !password) {
      console.log('❌ [ADD_USER] حقول مفقودة');
      return res.status(400).json({ error: 'جميع الحقول مطلوبة' });
    }

    if (phone && !validateSaudiPhone(phone)) {
      console.log('❌ [ADD_USER] رقم الهاتف غير صحيح:', phone);
      return res.status(400).json({ error: 'رقم الهاتف غير صحيح. يجب أن يكون رقم هاتف سعودي (مثال: 0501234567 أو +966501234567)' });
    }

    const existingUser = data.users.find(u => u.email === email);
    if (existingUser) {
      console.log('❌ [ADD_USER] البريد الإلكتروني مستخدم بالفعل:', email);
      return res.status(400).json({ error: 'البريد الإلكتروني مستخدم بالفعل' });
    }

    // تشفير كلمة المرور
    console.log('🟢 [ADD_USER] تشفير كلمة المرور...');
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log('🟢 [ADD_USER] Hash تم إنشاؤه، الطول:', hashedPassword ? hashedPassword.length : 'null');
    console.log('🟢 [ADD_USER] Hash start:', hashedPassword ? hashedPassword.substring(0, 20) : 'null');
    
    // التحقق من أن hash تم بنجاح
    if (!hashedPassword || hashedPassword.length < 20) {
      console.error('❌ [ADD_USER] خطأ في تشفير كلمة المرور');
      return res.status(500).json({ error: 'خطأ في تشفير كلمة المرور' });
    }
    console.log('✅ [ADD_USER] Hash صحيح');
    
    const normalizedPhone = phone ? normalizeSaudiPhone(phone) : null;
    const newId = getNextId('users');
    console.log('🟢 [ADD_USER] ID الجديد:', newId);

    const newUser = {
      id: newId,
      name,
      email,
      password: hashedPassword,
      phone: normalizedPhone,
      department: department || null,
      role: 'user',
      isActive: true,
      createdAt: new Date().toISOString()
    };
    console.log('🟢 [ADD_USER] كائن المستخدم الجديد تم إنشاؤه');

    // إضافة المستخدم
    data.users.push(newUser);
    console.log('🟢 [ADD_USER] المستخدم تم إضافته للذاكرة، العدد الجديد:', data.users.length);
    
    // حفظ البيانات
    console.log('🟢 [ADD_USER] حفظ البيانات...');
    const saved = saveData();
    if (!saved) {
      console.error('❌ [ADD_USER] خطأ في حفظ البيانات');
      return res.status(500).json({ error: 'خطأ في حفظ البيانات' });
    }
    console.log('✅ [ADD_USER] البيانات تم حفظها');
    
    // التحقق من أن البيانات تم حفظها بشكل صحيح
    console.log('🟢 [ADD_USER] التحقق من حفظ البيانات...');
    const verifyData = getDatabase();
    const savedUser = verifyData.users.find(u => u.id === newUser.id);
    if (!savedUser) {
      console.error('❌ [ADD_USER] المستخدم غير موجود بعد الحفظ!');
      return res.status(500).json({ error: 'خطأ في حفظ المستخدم' });
    }
    if (!savedUser.password || savedUser.password.length < 20) {
      console.error('❌ [ADD_USER] كلمة المرور لم يتم حفظها بشكل صحيح');
      console.error('   - Password exists:', !!savedUser.password);
      console.error('   - Password length:', savedUser.password ? savedUser.password.length : 0);
      return res.status(500).json({ error: 'خطأ في حفظ كلمة المرور' });
    }
    console.log('✅ [ADD_USER] التحقق ناجح - كلمة المرور محفوظة بشكل صحيح');
    console.log('✅ [ADD_USER] تم إضافة المستخدم بنجاح:', email);

    res.status(201).json({
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      role: newUser.role,
      department: newUser.department
    });
  } catch (error) {
    console.error('❌ [ADD_USER] خطأ في إضافة المستخدم:', error);
    console.error('❌ [ADD_USER] Stack:', error.stack);
    res.status(500).json({ error: 'خطأ في إضافة المستخدم' });
  }
});

// الحصول على معلومات المستخدم الحالي
app.get('/api/auth/me', authenticateToken, async (req, res) => {
  try {
    await initDbOnce();
    const data = getDatabase();
    const user = data.users.find(u => u.id === req.user.id);
    if (!user) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }
    res.json({ 
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        department: user.department
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في جلب البيانات' });
  }
});

// ========== Bookings Routes ==========

// الحصول على جميع الحجوزات
app.get('/api/bookings', authenticateToken, async (req, res) => {
  try {
    await initDbOnce();
    const data = getDatabase();
    
    let bookings = data.bookings.map(booking => {
      const user = data.users.find(u => u.id === booking.userId);
      const hall = data.halls.find(h => h.id === booking.hallId);
      return {
        ...booking,
        userName: user ? user.name : 'Unknown',
        userEmail: user ? user.email : 'Unknown',
        hallName: hall ? hall.name : 'Unknown'
      };
    });

    if (req.user.role !== 'admin') {
      bookings = bookings.filter(b => b.userId === req.user.id);
    }

    bookings.sort((a, b) => new Date(b.date) - new Date(a.date));
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: 'خطأ في جلب الحجوزات' });
  }
});

// إنشاء حجز جديد
app.post('/api/bookings', authenticateToken, async (req, res) => {
  try {
    await initDbOnce();
    const { hallId, date, startTime, endTime, duration, notes } = req.body;
    const data = getDatabase();

    if (!hallId || !date) {
      return res.status(400).json({ error: 'القاعة والتاريخ مطلوبان' });
    }

    const newId = getNextId('bookings');
    const newBooking = {
      id: newId,
      userId: req.user.id,
      hallId: parseInt(hallId),
      date,
      startTime: startTime || null,
      endTime: endTime || null,
      duration: duration || 'Full Day',
      status: 'pending',
      notes: notes || null,
      createdAt: new Date().toISOString()
    };

    data.bookings.push(newBooking);
    saveData();

    res.status(201).json({ id: newBooking.id, message: 'تم إنشاء طلب الحجز بنجاح' });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في إنشاء الحجز' });
  }
});

// تحديث حالة الحجز (أدمن فقط)
app.put('/api/bookings/:id/status', authenticateToken, isAdmin, async (req, res) => {
  try {
    await initDbOnce();
    const { status } = req.body;
    const data = getDatabase();

    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'حالة غير صحيحة' });
    }

    const bookingId = parseInt(req.params.id);
    const booking = data.bookings.find(b => b.id === bookingId);
    if (!booking) {
      return res.status(404).json({ error: 'الحجز غير موجود' });
    }

    booking.status = status;
    saveData();

    res.json({ message: 'تم تحديث الحجز بنجاح' });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في تحديث الحجز' });
  }
});

// ========== Calendar Route ==========
app.get('/api/calendar', authenticateToken, async (req, res) => {
  try {
    await initDbOnce();
    const { year, month } = req.query;
    const data = getDatabase();
    const targetMonth = `${year}-${String(month).padStart(2, '0')}`;

    const bookingsInMonth = data.bookings.filter(b => {
      const bookingDate = new Date(b.date);
      const bookingMonth = `${bookingDate.getFullYear()}-${String(bookingDate.getMonth() + 1).padStart(2, '0')}`;
      return bookingMonth === targetMonth;
    });

    const grouped = {};
    bookingsInMonth.forEach(booking => {
      if (!grouped[booking.date]) {
        grouped[booking.date] = { date: booking.date, count: 0, approved: 0, pending: 0 };
      }
      grouped[booking.date].count++;
      if (booking.status === 'approved') grouped[booking.date].approved++;
      if (booking.status === 'pending') grouped[booking.date].pending++;
    });

    res.json(Object.values(grouped));
  } catch (error) {
    res.status(500).json({ error: 'خطأ في جلب بيانات التقويم' });
  }
});

// ========== Halls Routes ==========

// الحصول على جميع القاعات
app.get('/api/halls', async (req, res) => {
  try {
    await initDbOnce();
    const data = getDatabase();
    const halls = data.halls.filter(h => h.isActive !== false).sort((a, b) => a.name.localeCompare(b.name));
    res.json(halls);
  } catch (error) {
    res.status(500).json({ error: 'خطأ في جلب القاعات' });
  }
});

// إضافة قاعة (أدمن فقط)
app.post('/api/halls', authenticateToken, isAdmin, async (req, res) => {
  try {
    await initDbOnce();
    const { name, capacity, description } = req.body;
    const data = getDatabase();

    if (!name) {
      return res.status(400).json({ error: 'اسم القاعة مطلوب' });
    }

    const newId = getNextId('halls');
    const newHall = {
      id: newId,
      name,
      capacity: capacity || null,
      description: description || null,
      isActive: true,
      createdAt: new Date().toISOString()
    };

    data.halls.push(newHall);
    saveData();

    res.status(201).json({ id: newHall.id, name, capacity, description });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في إضافة القاعة' });
  }
});

// تحديث قاعة (أدمن فقط)
app.put('/api/halls/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    await initDbOnce();
    const { name, capacity, description, isActive } = req.body;
    const data = getDatabase();
    const hallId = parseInt(req.params.id);

    const hall = data.halls.find(h => h.id === hallId);
    if (!hall) {
      return res.status(404).json({ error: 'القاعة غير موجودة' });
    }

    if (name !== undefined) hall.name = name;
    if (capacity !== undefined) hall.capacity = capacity;
    if (description !== undefined) hall.description = description;
    if (isActive !== undefined) hall.isActive = isActive;

    saveData();
    res.json({ message: 'تم تحديث القاعة بنجاح' });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في تحديث القاعة' });
  }
});

// حذف قاعة (أدمن فقط)
app.delete('/api/halls/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    await initDbOnce();
    const data = getDatabase();
    const hallId = parseInt(req.params.id);

    const hallIndex = data.halls.findIndex(h => h.id === hallId);
    if (hallIndex === -1) {
      return res.status(404).json({ error: 'القاعة غير موجودة' });
    }

    data.halls.splice(hallIndex, 1);
    saveData();

    res.json({ message: 'تم حذف القاعة بنجاح' });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في حذف القاعة' });
  }
});

// ========== Admin Routes ==========

// الحصول على جميع المستخدمين (أدمن فقط)
app.get('/api/admin/users', authenticateToken, isAdmin, async (req, res) => {
  try {
    await initDbOnce();
    const data = getDatabase();
    const users = data.users.map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      phone: u.phone,
      department: u.department,
      role: u.role,
      isActive: u.isActive,
      createdAt: u.createdAt
    })).sort((a, b) => a.name.localeCompare(b.name));
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'خطأ في جلب المستخدمين' });
  }
});

// تحديث مستخدم (أدمن فقط)
app.put('/api/admin/users/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    await initDbOnce();
    const { isActive, role } = req.body;
    const data = getDatabase();
    const userId = parseInt(req.params.id);

    const user = data.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }

    if (isActive !== undefined) user.isActive = isActive;
    if (role) user.role = role;

    saveData();
    res.json({ message: 'تم تحديث المستخدم بنجاح' });
  } catch (error) {
    res.status(500).json({ error: 'خطأ في تحديث المستخدم' });
  }
});

// الصفحة الرئيسية
app.get('/', (req, res) => {
  res.json({
    message: 'نظام حجز القاعات API',
    status: 'يعمل بنجاح',
    version: '2.0'
  });
});

// Export للاستخدام في التطوير المحلي وNetlify
module.exports = { app, initDbOnce };

// Export للـ Netlify Functions (serverless wrapper)
if (typeof require !== 'undefined') {
  try {
    const serverless = require('serverless-http');
    module.exports.handler = serverless(app);
  } catch (e) {
    // serverless-http غير متوفر (في التطوير المحلي)
  }
}

