import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';
import LanguageSwitcher from '../components/LanguageSwitcher';
import './AdminDashboard.css';
import './Login.css';

function AdminDashboard() {
  const { t } = useTranslation();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { addUser: addUserAPI } = useAuth();
  const [users, setUsers] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [halls, setHalls] = useState([]);
  const [activeTab, setActiveTab] = useState('bookings');
  const [loading, setLoading] = useState(true);
  const [newHall, setNewHall] = useState({ name: '', capacity: '', description: '' });
  const [editingHall, setEditingHall] = useState(null);
  const [showHallForm, setShowHallForm] = useState(false);
  const [showUserForm, setShowUserForm] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', phone: '', department: '' });
  const [userError, setUserError] = useState('');
  const [userLoading, setUserLoading] = useState(false);
  
  const departments = ['IT', 'HR', 'Finance', 'Marketing', 'Operations'];
  
  // Helper function to format Saudi phone numbers
  const formatPhoneNumber = (value) => {
    if (!value) return '';
    let numbers = value.replace(/[^\d+]/g, '');
    if (numbers.startsWith('05')) {
      numbers = '+966' + numbers.substring(1);
    } else if (numbers.startsWith('5') && !numbers.startsWith('+9665')) {
      numbers = '+966' + numbers;
    } else if (numbers.startsWith('966') && !numbers.startsWith('+966')) {
      numbers = '+' + numbers;
    } else if (!numbers.startsWith('+')) {
      numbers = '+966';
    }
    if (!numbers.startsWith('+966')) {
      return numbers;
    }
    const prefix = '+966';
    let rest = numbers.substring(prefix.length);
    if (rest.length === 0) return prefix;
    if (rest.length <= 1) return `${prefix} ${rest}`;
    if (rest.length <= 4) return `${prefix} ${rest.substring(0, 1)} ${rest.substring(1)}`;
    if (rest.length <= 7) return `${prefix} ${rest.substring(0, 1)} ${rest.substring(1, 4)} ${rest.substring(4)}`;
    return `${prefix} ${rest.substring(0, 1)} ${rest.substring(1, 4)} ${rest.substring(4, 7)} ${rest.substring(7, 9)}`;
  };
  
  const handleUserPhoneChange = (e) => {
    const value = formatPhoneNumber(e.target.value);
    setNewUser({ ...newUser, phone: value });
  };
  
  const handleUserPhoneFocus = (e) => {
    if (e.target.value === '') {
      setNewUser({ ...newUser, phone: '+966' });
    }
  };
  
  const handleUserPhoneKeyDown = (e) => {
    if (e.key === 'Backspace' && e.target.selectionStart <= 4 && e.target.value.startsWith('+966')) {
      if (e.target.selectionStart < 4) {
        e.preventDefault();
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [usersRes, bookingsRes, hallsRes] = await Promise.all([
        api.get('/api/admin/users'),
        api.get('/api/bookings'),
        api.get('/api/halls')
      ]);
      setUsers(usersRes.data);
      setBookings(bookingsRes.data);
      setHalls(hallsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (bookingId, status) => {
    try {
      await api.put(`/api/bookings/${bookingId}/status`, { status });
      fetchData();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleUserUpdate = async (userId, updates) => {
    try {
      await api.put(`/api/admin/users/${userId}`, updates);
      fetchData();
    } catch (error) {
      console.error('Error updating user:', error);
      alert(error.response?.data?.error || 'خطأ في تحديث المستخدم');
    }
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    setUserError('');
    setUserLoading(true);
    
    // التحقق من أن المستخدم أدمن
    if (!user || user.role !== 'admin') {
      setUserError('يجب أن تكون أدمن لإضافة مستخدمين');
      setUserLoading(false);
      return;
    }
    
    try {
      const result = await addUserAPI(
        newUser.name,
        newUser.email,
        newUser.password,
        newUser.phone,
        newUser.department
      );
      if (result.success) {
        setNewUser({ name: '', email: '', password: '', phone: '', department: '' });
        setShowUserForm(false);
        setUserError('');
        fetchData(); // تحديث القائمة
      } else {
        setUserError(result.error || 'خطأ في إضافة المستخدم');
      }
    } catch (error) {
      console.error('Error adding user:', error);
      setUserError(error.response?.data?.error || 'خطأ في إضافة المستخدم');
    } finally {
      setUserLoading(false);
    }
  };

  const handleAddHall = async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/halls', newHall);
      setNewHall({ name: '', capacity: '', description: '' });
      setShowHallForm(false);
      fetchData();
    } catch (error) {
      console.error('Error adding hall:', error);
      alert(error.response?.data?.error || 'خطأ في إضافة القاعة');
    }
  };

  const handleEditHall = (hall) => {
    setEditingHall(hall);
    setNewHall({ name: hall.name, capacity: hall.capacity || '', description: hall.description || '' });
    setShowHallForm(true);
  };

  const handleUpdateHall = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/api/halls/${editingHall.id}`, newHall);
      setEditingHall(null);
      setNewHall({ name: '', capacity: '', description: '' });
      setShowHallForm(false);
      fetchData();
    } catch (error) {
      console.error('Error updating hall:', error);
      alert(error.response?.data?.error || 'خطأ في تحديث القاعة');
    }
  };

  const handleDeleteHall = async (hallId) => {
    if (window.confirm('هل أنت متأكد من حذف هذه القاعة؟')) {
      try {
        await api.delete(`/api/halls/${hallId}`);
        fetchData();
      } catch (error) {
        console.error('Error deleting hall:', error);
        alert(error.response?.data?.error || 'خطأ في حذف القاعة');
      }
    }
  };

  const cancelHallForm = () => {
    setEditingHall(null);
    setNewHall({ name: '', capacity: '', description: '' });
    setShowHallForm(false);
  };

  return (
    <div className="admin-container">
      <div className="admin-header">
        <button 
          onClick={() => navigate('/dashboard')} 
          className="back-button"
          style={{
            marginRight: '10px',
            padding: '8px 16px',
            backgroundColor: '#f0f0f0',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          ← {t('back')}
        </button>
        <h1>{t('adminDashboard')}</h1>
        <div className="header-actions">
          <LanguageSwitcher />
          <button className="btn-logout" onClick={logout}>{t('logout')}</button>
        </div>
      </div>

      <div className="admin-tabs">
        <button
          className={activeTab === 'bookings' ? 'active' : ''}
          onClick={() => setActiveTab('bookings')}
        >
          {t('bookings')}
        </button>
        <button
          className={activeTab === 'users' ? 'active' : ''}
          onClick={() => setActiveTab('users')}
        >
          {t('users')}
        </button>
        <button
          className={activeTab === 'halls' ? 'active' : ''}
          onClick={() => setActiveTab('halls')}
        >
          {t('halls')}
        </button>
      </div>

      {activeTab === 'bookings' && (
        <div className="admin-section">
          <h2>{t('bookingRequests')}</h2>
          <div className="bookings-list">
            {bookings.map((booking) => (
              <div key={booking.id} className="booking-item">
                <div className="booking-details">
                  <h3>{booking.hallName}</h3>
                  <p>{booking.userName} ({booking.userEmail})</p>
                  <p>{new Date(booking.date).toLocaleDateString()}</p>
                  <p>{booking.duration === 'Full Day' ? t('fullDay') : `${booking.startTime} - ${booking.endTime}`}</p>
                </div>
                <div className="booking-actions">
                  <span className={`status-badge status-${booking.status}`}>
                    {t(booking.status)}
                  </span>
                  {booking.status === 'pending' && (
                    <div className="action-buttons">
                      <button
                        className="btn-approve"
                        onClick={() => handleStatusChange(booking.id, 'approved')}
                      >
                        {t('approve')}
                      </button>
                      <button
                        className="btn-reject"
                        onClick={() => handleStatusChange(booking.id, 'rejected')}
                      >
                        {t('reject')}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="admin-section">
          <h2>{t('usersManagement')}</h2>
          
          {!showUserForm ? (
            <button className="btn-add-hall" onClick={() => { setShowUserForm(true); setUserError(''); }}>
              + {t('addUser')}
            </button>
          ) : (
            <div className="auth-card" style={{ maxWidth: '500px', margin: '0 auto 30px' }}>
              <div className="auth-header">
                <h3 className="auth-title">{t('addUser')}</h3>
                <button 
                  type="button"
                  onClick={() => { 
                    setShowUserForm(false); 
                    setNewUser({ name: '', email: '', password: '', phone: '', department: '' }); 
                    setUserError('');
                  }}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    fontSize: '1.5rem', 
                    cursor: 'pointer',
                    color: '#718096'
                  }}
                >
                  ×
                </button>
              </div>
              
              <form onSubmit={handleAddUser} className="auth-form">
                {userError && <div className="error-message">{userError}</div>}

                <div className="form-group">
                  <label>{t('fullName')}</label>
                  <input
                    type="text"
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    placeholder="John Doe"
                    required
                  />
                </div>

                <div className="form-group">
                  <label>{t('email')}</label>
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    placeholder="you@example.com"
                    required
                  />
                </div>

                <div className="form-group">
                  <label>{t('phone')} <span style={{fontSize: '0.85rem', color: '#718096'}}>({t('saudiPhone')})</span></label>
                  <input
                    type="tel"
                    value={newUser.phone}
                    onChange={handleUserPhoneChange}
                    onFocus={handleUserPhoneFocus}
                    onKeyDown={handleUserPhoneKeyDown}
                    placeholder={t('phonePlaceholder') || '+966 5X XXX XXXX'}
                    className="phone-input"
                    style={{ direction: 'ltr', fontFamily: 'monospace' }}
                  />
                  <small style={{color: '#718096', fontSize: '0.85rem'}}>
                    {t('phoneFormat')}
                  </small>
                </div>

                <div className="form-group">
                  <label>{t('department')}</label>
                  <select
                    value={newUser.department}
                    onChange={(e) => setNewUser({ ...newUser, department: e.target.value })}
                    required
                  >
                    <option value="">{t('selectDepartment')}</option>
                    {departments.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>{t('password')}</label>
                  <input
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    placeholder="Enter password"
                    required
                    minLength="6"
                  />
                </div>

                <button type="submit" className="auth-button" disabled={userLoading}>
                  {userLoading ? t('registering') || 'جاري الإضافة...' : t('addUser')}
                </button>
              </form>
            </div>
          )}

          <div className="users-list">
            {users.map((u) => (
              <div key={u.id} className="user-item">
                <div className="user-info">
                  <h3>{u.name}</h3>
                  <p>{u.email}</p>
                  {u.phone && <p>{t('phone')}: {u.phone}</p>}
                  <p>{t('department')}: {u.department || 'N/A'}</p>
                  <p>{t('role')}: {u.role}</p>
                </div>
                <div className="user-actions">
                  <label>
                    <input
                      type="checkbox"
                      checked={u.isActive === true || u.isActive === 1}
                      onChange={(e) => handleUserUpdate(u.id, { isActive: e.target.checked })}
                    />
                    {t('active')}
                  </label>
                  {u.role !== 'admin' && (
                    <button
                      className="btn-make-admin"
                      onClick={() => handleUserUpdate(u.id, { role: 'admin' })}
                    >
                      {t('makeAdmin')}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'halls' && (
        <div className="admin-section">
          <h2>{t('hallsManagement')}</h2>
          
          {!showHallForm ? (
            <button className="btn-add-hall" onClick={() => setShowHallForm(true)}>
              + {t('addHall')}
            </button>
          ) : (
            <form onSubmit={editingHall ? handleUpdateHall : handleAddHall} className="hall-form">
              <h3>{editingHall ? t('editHall') : t('addHall')}</h3>
              <input
                type="text"
                placeholder={t('hallName')}
                value={newHall.name}
                onChange={(e) => setNewHall({ ...newHall, name: e.target.value })}
                required
              />
              <input
                type="number"
                placeholder={t('capacity')}
                value={newHall.capacity}
                onChange={(e) => setNewHall({ ...newHall, capacity: e.target.value })}
              />
              <input
                type="text"
                placeholder={t('description')}
                value={newHall.description}
                onChange={(e) => setNewHall({ ...newHall, description: e.target.value })}
              />
              <div className="form-buttons">
                <button type="submit" className="btn-save">{t('save')}</button>
                <button type="button" className="btn-cancel" onClick={cancelHallForm}>{t('cancel')}</button>
              </div>
            </form>
          )}

          <div className="halls-list">
            {halls.map((hall) => (
              <div key={hall.id} className="hall-item">
                <div className="hall-info">
                  <h3>{hall.name}</h3>
                  <p>{t('capacity')}: {hall.capacity || 'N/A'}</p>
                  <p>{hall.description}</p>
                </div>
                <div className="hall-actions">
                  <button
                    className="btn-edit"
                    onClick={() => handleEditHall(hall)}
                  >
                    {t('edit')}
                  </button>
                  <button
                    className="btn-delete"
                    onClick={() => handleDeleteHall(hall.id)}
                  >
                    {t('delete')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;
