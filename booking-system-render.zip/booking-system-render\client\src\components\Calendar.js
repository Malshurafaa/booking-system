import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday } from 'date-fns';
import api from '../api/axios';
import './Calendar.css';

function Calendar({ onDateSelect }) {
  const { t } = useTranslation();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [bookings, setBookings] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCalendarData();
  }, [currentDate]);

  const fetchCalendarData = async () => {
    try {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth() + 1;
      const response = await api.get(`/api/calendar?year=${year}&month=${month}`);
      
      const bookingsMap = {};
      response.data.forEach(item => {
        bookingsMap[item.date] = {
          count: item.count,
          approved: item.approved,
          pending: item.pending
        };
      });
      
      setBookings(bookingsMap);
    } catch (error) {
      console.error('Error fetching calendar:', error);
    } finally {
      setLoading(false);
    }
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getDateStatus = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const booking = bookings[dateStr];
    
    if (!booking) return 'available';
    if (booking.approved >= 3) return 'fully-booked';
    if (booking.pending > 0 || booking.approved > 0) return 'partially-available';
    return 'available';
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  if (loading) {
    return <div className="calendar-loading">جاري تحميل التقويم...</div>;
  }

  return (
    <div className="calendar-container">
      <div className="calendar-header">
        <button onClick={prevMonth} className="calendar-nav-btn">‹</button>
        <h2 className="calendar-month">{format(currentDate, 'MMMM yyyy')}</h2>
        <button onClick={nextMonth} className="calendar-nav-btn">›</button>
      </div>

      <div className="calendar-grid">
        {days.map((day, index) => {
          const status = getDateStatus(day);
          const isCurrentMonth = isSameMonth(day, currentDate);
          const isTodayDate = isToday(day);
          const dateStr = format(day, 'yyyy-MM-dd');
          const booking = bookings[dateStr];

          return (
            <button
              key={index}
              className={`calendar-day ${status} ${isTodayDate ? 'today' : ''} ${!isCurrentMonth ? 'other-month' : ''}`}
              onClick={() => onDateSelect && onDateSelect(day)}
              disabled={!isCurrentMonth}
              style={{ animationDelay: `${index * 0.02}s` }}
            >
              <span className="day-number">{format(day, 'd')}</span>
              {booking && (
                <span className="day-badge">{booking.count}</span>
              )}
            </button>
          );
        })}
      </div>

      <div className="calendar-legend">
        <div className="legend-item">
          <span className="legend-color fully-booked"></span>
          <span>{t('fullyBooked')}</span>
        </div>
        <div className="legend-item">
          <span className="legend-color partially-available"></span>
          <span>{t('partiallyAvailable')}</span>
        </div>
        <div className="legend-item">
          <span className="legend-color available"></span>
          <span>{t('available')}</span>
        </div>
      </div>
    </div>
  );
}

export default Calendar;

