// استخدام api-app.js مباشرة للتطوير المحلي
const { app } = require('../netlify/functions/api-app');

const PORT = process.env.PORT || 5000;

// بدء الخادم
async function startServer() {
  try {
    app.listen(PORT, () => {
      console.log(`🚀 الخادم يعمل على المنفذ ${PORT}`);
      console.log(`📊 قاعدة البيانات JSON جاهزة`);
      console.log(`🔗 API متاح على: http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('خطأ في بدء الخادم:', error);
    process.exit(1);
  }
}

startServer();
