import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import api from '../api/axios';
import LanguageSwitcher from '../components/LanguageSwitcher';
import './BookHall.css';

function BookHall() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const [halls, setHalls] = useState([]);
  const [formData, setFormData] = useState({
    hallId: '',
    date: location.state?.selectedDate || '',
    duration: 'Full Day',
    startTime: '',
    endTime: '',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchHalls();
  }, []);

  const fetchHalls = async () => {
    try {
      const response = await api.get('/api/halls');
      setHalls(response.data);
    } catch (error) {
      console.error('Error fetching halls:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await api.post('/api/bookings', formData);
      navigate('/dashboard');
    } catch (error) {
      setError(error.response?.data?.error || 'خطأ في إنشاء الحجز');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="book-hall-container">
      <div className="book-hall-card">
        <div className="book-hall-header">
          <button 
            onClick={() => navigate('/dashboard')} 
            className="back-button"
            style={{
              marginBottom: '10px',
              padding: '8px 16px',
              backgroundColor: '#f0f0f0',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            ← {t('back')}
          </button>
          <h1 className="book-hall-title">{t('bookHall')}</h1>
          <LanguageSwitcher />
        </div>

        <form onSubmit={handleSubmit} className="book-hall-form">
          {error && <div className="error-message">{error}</div>}

          <div className="form-group">
            <label>{t('selectHall')}</label>
            <select
              name="hallId"
              value={formData.hallId}
              onChange={handleChange}
              required
            >
              <option value="">{t('chooseHall')}</option>
              {halls.map((hall) => (
                <option key={hall.id} value={hall.id}>
                  {hall.name} {hall.capacity && `(${hall.capacity} ${t('capacity')})`}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>{t('date')}</label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
              min={new Date().toISOString().split('T')[0]}
            />
          </div>

          <div className="form-group">
            <label>{t('bookingDuration')}</label>
            <div className="radio-group">
              <label className="radio-label">
                <input
                  type="radio"
                  name="duration"
                  value="Full Day"
                  checked={formData.duration === 'Full Day'}
                  onChange={handleChange}
                />
                {t('fullDay')}
              </label>
              <label className="radio-label">
                <input
                  type="radio"
                  name="duration"
                  value="Specific Time Slot"
                  checked={formData.duration === 'Specific Time Slot'}
                  onChange={handleChange}
                />
                {t('specificTimeSlot')}
              </label>
            </div>
          </div>

          {formData.duration === 'Specific Time Slot' && (
            <>
              <div className="form-group">
                <label>{t('startTime')}</label>
                <input
                  type="time"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleChange}
                  required={formData.duration === 'Specific Time Slot'}
                />
              </div>
              <div className="form-group">
                <label>{t('endTime')}</label>
                <input
                  type="time"
                  name="endTime"
                  value={formData.endTime}
                  onChange={handleChange}
                  required={formData.duration === 'Specific Time Slot'}
                />
              </div>
            </>
          )}

          <div className="form-group">
            <label>{t('notes')} ({t('optional')})</label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows="4"
              placeholder="Any additional notes..."
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={() => navigate('/dashboard')}>
              {t('cancel')}
            </button>
            <button type="submit" className="btn-submit" disabled={loading}>
              {loading ? 'Submitting...' : t('submitBookingRequest')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default BookHall;

