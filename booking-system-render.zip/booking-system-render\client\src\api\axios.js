import axios from 'axios';

// في الإنتاج (Netlify)، استخدم نفس الدومين
// في التطوير، استخدم localhost:5000 مباشرة
const api = axios.create({
  baseURL: process.env.NODE_ENV === 'production' 
    ? '' // نفس الدومين (Netlify)
    : (process.env.REACT_APP_API_URL || 'http://localhost:5000'), // في التطوير
  headers: {
    'Content-Type': 'application/json'
  }
});

// إضافة التوكن تلقائياً
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

// معالجة الأخطاء
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 || error.response?.status === 403) {
      // إذا كان الخطأ "غير مصرح"، أزل الـ token وأعد التوجيه للدخول
      if (error.response?.data?.error === 'غير مصرح' || error.response?.data?.error === 'توكن غير صالح') {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default api;

