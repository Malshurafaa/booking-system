const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// مسار ملف JSON - استخدام مسار ثابت دائماً
const DATA_FILE = path.join(__dirname, 'data', 'database.json');

// مسار ملف JSON الجاهز في المشروع
const READY_DATA_FILE = path.join(__dirname, 'data', 'database.json');

let data = null;

// قراءة البيانات من JSON
function loadData() {
  try {
    // إنشاء مجلد data إذا لم يكن موجوداً
    const dataDir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // إذا لم يكن ملف JSON موجوداً، أنشئه
    if (!fs.existsSync(DATA_FILE)) {
      console.log('⚠️ ملف JSON غير موجود، سيتم إنشاؤه');
      initializeDefaultData();
    }
    
    // قراءة البيانات
    const fileContent = fs.readFileSync(DATA_FILE, 'utf8');
    data = JSON.parse(fileContent);
    
    // التأكد من وجود جميع المصفوفات
    if (!data.users) data.users = [];
    if (!data.halls) data.halls = [];
    if (!data.bookings) data.bookings = [];
    
    console.log('✅ تم تحميل البيانات من JSON');
    return data;
  } catch (error) {
    console.error('❌ خطأ في قراءة ملف JSON:', error);
    // إنشاء بيانات افتراضية
    initializeDefaultData();
    return loadData();
  }
}

// حفظ البيانات في JSON
function saveData() {
  try {
    // تأكد من وجود مجلد data
    const dataDir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    console.log('✅ تم حفظ البيانات في:', DATA_FILE);
    return true;
  } catch (error) {
    console.error('❌ خطأ في حفظ ملف JSON:', error);
    return false;
  }
}

// تهيئة بيانات افتراضية
function initializeDefaultData() {
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@example.com';
  const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
  const adminPasswordHash = bcrypt.hashSync(adminPassword, 10);
  
  data = {
    users: [
      {
        id: 1,
        name: "Admin User",
        email: adminEmail,
        password: adminPasswordHash,
        phone: null,
        department: null,
        role: "admin",
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ],
    halls: [
      {
        id: 1,
        name: "Main Hall",
        capacity: 100,
        description: "القاعة الرئيسية",
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        name: "Conference Room A",
        capacity: 50,
        description: "قاعة المؤتمرات أ",
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 3,
        name: "Conference Room B",
        capacity: 30,
        description: "قاعة المؤتمرات ب",
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 4,
        name: "Meeting Room 1",
        capacity: 20,
        description: "قاعة الاجتماعات 1",
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ],
    bookings: []
  };
  
  saveData();
  console.log('✅ تم إنشاء بيانات افتراضية');
}

// تهيئة قاعدة البيانات
function initDatabase() {
  return new Promise((resolve, reject) => {
    try {
      loadData();
      console.log('✅ قاعدة البيانات JSON جاهزة');
      resolve();
    } catch (error) {
      console.error('❌ خطأ في تهيئة قاعدة البيانات:', error);
      reject(error);
    }
  });
}

// الحصول على البيانات
function getDatabase() {
  if (!data) {
    loadData();
  }
  return data;
}

// الحصول على ID التالي
function getNextId(collection) {
  if (!data || !data[collection] || data[collection].length === 0) {
    return 1;
  }
  return Math.max(...data[collection].map(item => item.id || 0)) + 1;
}

// إغلاق قاعدة البيانات (لا حاجة له في JSON)
function closeDatabase() {
  return Promise.resolve();
}

module.exports = {
  initDatabase,
  getDatabase,
  saveData,
  getNextId,
  closeDatabase
};
