import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="header-content">
        <h1>📅 نظام الحجز</h1>
        <p>إدارة الحجوزات بسهولة وفعالية</p>
      </div>
    </header>
  );
};

export default Header;

