import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import api from '../api/axios';
import Calendar from '../components/Calendar';
import LanguageSwitcher from '../components/LanguageSwitcher';
import { format } from 'date-fns';
import './Dashboard.css';

function Dashboard() {
  const { t } = useTranslation();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const response = await api.get('/api/bookings');
      setBookings(response.data);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusMap = {
      pending: { class: 'status-pending' },
      approved: { class: 'status-approved' },
      rejected: { class: 'status-rejected' }
    };
    const statusInfo = statusMap[status] || statusMap.pending;
    return <span className={`status-badge ${statusInfo.class}`}>{t(status)}</span>;
  };

  const handleDateSelect = (date) => {
    navigate('/book', { state: { selectedDate: format(date, 'yyyy-MM-dd') } });
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <button 
          onClick={() => navigate('/')} 
          className="back-button"
          style={{
            marginLeft: '10px',
            padding: '8px 16px',
            backgroundColor: '#f0f0f0',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          ← {t('back')}
        </button>
        <div>
          <h1 className="dashboard-title">{t('dashboard')}</h1>
          <p className="dashboard-welcome">{t('welcomeBack')}, {user?.name}</p>
        </div>
        <div className="dashboard-actions">
          <LanguageSwitcher />
          <button className="btn-primary" onClick={() => navigate('/book')}>
            <span>+</span> {t('newBooking')}
          </button>
          {user?.role === 'admin' && (
            <button className="btn-secondary" onClick={() => navigate('/admin')}>
              {t('adminPanel')}
            </button>
          )}
          <button className="btn-outline" onClick={logout}>
            {t('logout')}
          </button>
        </div>
      </div>

      <Calendar onDateSelect={handleDateSelect} />

      <div className="my-requests">
        <h2 className="section-title">{t('myRequests')}</h2>
        {loading ? (
          <div className="loading">جاري التحميل...</div>
        ) : bookings.length === 0 ? (
          <div className="empty-state">
            <p>{t('noBookings')}</p>
            <button className="btn-primary" onClick={() => navigate('/book')}>
              {t('createNewBooking')}
            </button>
          </div>
        ) : (
          <div className="bookings-list">
            {bookings.map((booking) => (
              <div key={booking.id} className="booking-card">
                <div className="booking-info">
                  <h3>{booking.hallName}</h3>
                  <p className="booking-date">
                    {new Date(booking.date).toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                  <p className="booking-duration">
                    {booking.duration === 'Full Day' 
                      ? t('fullDay') 
                      : `${booking.startTime} - ${booking.endTime}`}
                  </p>
                </div>
                <div className="booking-status">
                  {getStatusBadge(booking.status)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Dashboard;

