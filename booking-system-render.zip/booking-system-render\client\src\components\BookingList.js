import React from 'react';
import './BookingList.css';

const BookingList = ({ bookings, onEdit, onDelete }) => {
  const getStatusBadge = (status) => {
    const statusMap = {
      pending: { text: 'قيد الانتظار', class: 'status-pending' },
      confirmed: { text: 'مؤكد', class: 'status-confirmed' },
      cancelled: { text: 'ملغي', class: 'status-cancelled' },
      completed: { text: 'مكتمل', class: 'status-completed' }
    };
    const statusInfo = statusMap[status] || statusMap.pending;
    return <span className={`status-badge ${statusInfo.class}`}>{statusInfo.text}</span>;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (bookings.length === 0) {
    return (
      <div className="empty-state">
        <p>لا توجد حجوزات حالياً</p>
        <p className="empty-state-subtitle">قم بإنشاء حجز جديد للبدء</p>
      </div>
    );
  }

  return (
    <div className="booking-list">
      <h2>قائمة الحجوزات ({bookings.length})</h2>
      <div className="bookings-grid">
        {bookings.map(booking => (
          <div key={booking.id} className="booking-card">
            <div className="booking-header">
              <h3>{booking.name}</h3>
              {getStatusBadge(booking.status)}
            </div>
            <div className="booking-details">
              <div className="detail-item">
                <span className="detail-label">📧 البريد:</span>
                <span className="detail-value">{booking.email}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">📱 الهاتف:</span>
                <span className="detail-value">{booking.phone}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">🛎️ الخدمة:</span>
                <span className="detail-value">{booking.service}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">📅 التاريخ:</span>
                <span className="detail-value">{booking.date}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">⏰ الوقت:</span>
                <span className="detail-value">{booking.time}</span>
              </div>
              {booking.notes && (
                <div className="detail-item">
                  <span className="detail-label">📝 الملاحظات:</span>
                  <span className="detail-value">{booking.notes}</span>
                </div>
              )}
              {booking.createdAt && (
                <div className="detail-item">
                  <span className="detail-label">🕐 تاريخ الإنشاء:</span>
                  <span className="detail-value">{formatDate(booking.createdAt)}</span>
                </div>
              )}
            </div>
            <div className="booking-actions">
              <button
                className="btn btn-success"
                onClick={() => onEdit(booking)}
              >
                تعديل
              </button>
              <button
                className="btn btn-danger"
                onClick={() => onDelete(booking.id)}
              >
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookingList;

