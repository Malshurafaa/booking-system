import React, { useState, useEffect } from 'react';
import './BookingForm.css';

const BookingForm = ({ booking, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    service: '',
    notes: ''
  });

  const [services, setServices] = useState([]);

  useEffect(() => {
    fetchServices();
    if (booking) {
      setFormData({
        name: booking.name || '',
        email: booking.email || '',
        phone: booking.phone || '',
        date: booking.date || '',
        time: booking.time || '',
        service: booking.service || '',
        notes: booking.notes || ''
      });
    }
  }, [booking]);

  const fetchServices = async () => {
    try {
      const response = await fetch('/api/services');
      const data = await response.json();
      setServices(data);
    } catch (error) {
      console.error('خطأ في جلب الخدمات:', error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time || !formData.service) {
      alert('يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    onSubmit(formData);
  };

  return (
    <div className="booking-form-container">
      <h2>{booking ? 'تعديل الحجز' : 'حجز جديد'}</h2>
      <form onSubmit={handleSubmit} className="booking-form">
        <div className="form-row">
          <div className="form-group">
            <label>الاسم الكامل *</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="أدخل الاسم الكامل"
            />
          </div>
          <div className="form-group">
            <label>البريد الإلكتروني *</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="example@email.com"
            />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>رقم الهاتف *</label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              placeholder="05xxxxxxxx"
            />
          </div>
          <div className="form-group">
            <label>الخدمة *</label>
            <select
              name="service"
              value={formData.service}
              onChange={handleChange}
              required
            >
              <option value="">اختر الخدمة</option>
              {services.map(service => (
                <option key={service.id} value={service.name}>
                  {service.name} - {service.duration} دقيقة - {service.price} ريال
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>التاريخ *</label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
              min={new Date().toISOString().split('T')[0]}
            />
          </div>
          <div className="form-group">
            <label>الوقت *</label>
            <input
              type="time"
              name="time"
              value={formData.time}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <div className="form-group">
          <label>ملاحظات</label>
          <textarea
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows="4"
            placeholder="أي ملاحظات إضافية..."
          />
        </div>

        <div className="form-actions">
          <button type="submit" className="btn btn-primary">
            {booking ? 'تحديث الحجز' : 'إنشاء الحجز'}
          </button>
          <button type="button" className="btn btn-secondary" onClick={onCancel}>
            إلغاء
          </button>
        </div>
      </form>
    </div>
  );
};

export default BookingForm;

